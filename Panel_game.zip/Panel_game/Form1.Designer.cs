using System.Drawing;
using System.Windows.Forms;

namespace Panel_game
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private Panel playArea;
        private Panel bottomPanel;
        private Label bombLabel;
        private Label label1;
        private Label label2;
        private Button button1;
        private Button button2;
        private Button button3;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();

            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            playArea = new Panel();
            bombLabel = new Label();
            bottomPanel = new Panel();
            label1 = new Label();
            label2 = new Label();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();

            SuspendLayout();

            // Oyun sahəsi
            playArea.BackColor = Color.White;
            playArea.Dock = DockStyle.Fill;
            playArea.Location = new Point(0, 0);
            playArea.Name = "playArea";
            playArea.Size = new Size(857, 456);
            playArea.TabIndex = 0;

            // Bomba
            bombLabel.AutoSize = false;
            bombLabel.BackColor = Color.Transparent;
            bombLabel.Font = new Font("Segoe UI Emoji", 27F, FontStyle.Regular, GraphicsUnit.Point);
            bombLabel.Location = new Point(70, 175);
            bombLabel.Name = "bombLabel";
            bombLabel.Size = new Size(48, 48);
            bombLabel.Text = "💣";
            bombLabel.TextAlign = ContentAlignment.MiddleCenter;
            bombLabel.TabIndex = 0;

            // Aşağı idarəetmə paneli
            bottomPanel.BackColor = Color.Gray;
            bottomPanel.Dock = DockStyle.Bottom;
            bottomPanel.Height = 64;
            bottomPanel.Name = "bottomPanel";
            bottomPanel.Padding = new Padding(24, 8, 24, 8);
            bottomPanel.TabIndex = 1;

            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label1.ForeColor = Color.White;
            label1.Location = new Point(48, 27);
            label1.Name = "label1";
            label1.Text = "Xal:";

            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label2.ForeColor = Color.White;
            label2.Location = new Point(104, 27);
            label2.Name = "label2";
            label2.Text = "0";

            button1.Anchor = AnchorStyles.Top;
            button1.BackColor = Color.Gray;
            button1.FlatStyle = FlatStyle.Flat;
            button1.FlatAppearance.BorderColor = Color.White;
            button1.FlatAppearance.BorderSize = 2;
            button1.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button1.ForeColor = Color.White;
            button1.Location = new Point(206, 15);
            button1.Name = "button1";
            button1.Size = new Size(138, 40);
            button1.Text = "Panel yarat";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;

            button2.Anchor = AnchorStyles.Top;
            button2.BackColor = Color.Gray;
            button2.FlatStyle = FlatStyle.Flat;
            button2.FlatAppearance.BorderColor = Color.White;
            button2.FlatAppearance.BorderSize = 2;
            button2.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button2.ForeColor = Color.White;
            button2.Location = new Point(395, 15);
            button2.Name = "button2";
            button2.Size = new Size(224, 40);
            button2.Text = "Bombanın yerini dəyiş";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;

            button3.Anchor = AnchorStyles.Top;
            button3.BackColor = Color.Gray;
            button3.FlatStyle = FlatStyle.Flat;
            button3.FlatAppearance.BorderColor = Color.White;
            button3.FlatAppearance.BorderSize = 2;
            button3.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button3.ForeColor = Color.White;
            button3.Location = new Point(674, 15);
            button3.Name = "button3";
            button3.Size = new Size(138, 40);
            button3.Text = "Çıxış";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;

            bottomPanel.Controls.Add(label1);
            bottomPanel.Controls.Add(label2);
            bottomPanel.Controls.Add(button1);
            bottomPanel.Controls.Add(button2);
            bottomPanel.Controls.Add(button3);

            playArea.Controls.Add(bombLabel);

            // Form
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(857, 520);
            Controls.Add(playArea);
            Controls.Add(bottomPanel);
            MinimumSize = new Size(700, 450);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Panel game";

            ResumeLayout(false);
        }
    }
}
