using System;
using System.Drawing;
using System.Windows.Forms;

namespace Panel_game
{
    public partial class Form1 : Form
    {
        private readonly Random random = new Random();
        private int count = 0;
        private bool gameOver = false;

        public Form1()
        {
            InitializeComponent();
            MoveBomb();
            UpdateScore();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (gameOver)
                return;

            // Yeni panel üçün təsadüfi rəng və mövqe yaradılır.
            Panel p = new Panel();
            p.Size = new Size(50, 50);
            p.BackColor = Color.FromArgb(
                random.Next(256),
                random.Next(256),
                random.Next(256));

            int maxX = Math.Max(1, playArea.ClientSize.Width - p.Width);
            int maxY = Math.Max(1, playArea.ClientSize.Height - p.Height);
            p.Location = new Point(random.Next(maxX), random.Next(maxY));

            playArea.Controls.Add(p);
            p.BringToFront();
            bombLabel.BringToFront();

            count++;
            UpdateScore();

            // Yaradılan panel hazırkı bomba mövqeyi ilə kəsişirsə oyun bitir.
            if (p.Bounds.IntersectsWith(bombLabel.Bounds))
            {
                EndGame();
            }
            else
            {
                // Hər "Panel yarat" klikindən sonra bomba yeni təsadüfi yerə keçir.
                MoveBomb();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!gameOver)
                MoveBomb();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void MoveBomb()
        {
            int maxX = Math.Max(1, playArea.ClientSize.Width - bombLabel.Width);
            int maxY = Math.Max(1, playArea.ClientSize.Height - bombLabel.Height);

            bombLabel.Location = new Point(random.Next(maxX), random.Next(maxY));
            bombLabel.BringToFront();
        }

        private void EndGame()
        {
            if (gameOver)
                return;

            gameOver = true;
            MessageBox.Show(
                this,
                "Bomba ilə toqquşdunuz! Oyun bitdi. Yenidən başlamaq üçün OK düyməsinə basın.",
                "Oyun bitdi",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);

            // OK basıldıqdan sonra oyun avtomatik yenidən başlayır.
            RestartGame();
        }

        private void RestartGame()
        {
            // Yaradılmış panelləri təhlükəsiz şəkildə silirik.
            for (int i = playArea.Controls.Count - 1; i >= 0; i--)
            {
                Control control = playArea.Controls[i];
                if (control is Panel && control != bombLabel)
                {
                    playArea.Controls.RemoveAt(i);
                    control.Dispose();
                }
            }

            count = 0;
            gameOver = false;
            UpdateScore();
            MoveBomb();
        }

        private void UpdateScore()
        {
            label2.Text = count.ToString();
        }
    }
}
