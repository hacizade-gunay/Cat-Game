PANEL GAME — Visual Studio layihəsi

Açmaq:
1. ZIP faylını çıxarın.
2. Panel_game qovluğundakı Panel_game.csproj faylını Visual Studio 2022 ilə açın.
3. .NET 8 SDK və Windows Forms dəstəyi quraşdırılmış olmalıdır.
4. F5 düyməsi ilə başladın.

İdarəetmə:
- Panel yarat: təsadüfi rəngli panel yaradır və xalı 1 artırır.
- Panel bomba ilə toqquşarsa oyun bitir. Açılan pəncərədə OK basıldıqdan sonra oyun yenidən başlayır.
- Bombanın yerini dəyiş: bombanı təsadüfi yeni yerə aparır.
- Çıxış: oyun pəncərəsini bağlayır.

Layihə faylları:
- Program.cs
- Form1.cs
- Form1.Designer.cs
- Panel_game.csproj
